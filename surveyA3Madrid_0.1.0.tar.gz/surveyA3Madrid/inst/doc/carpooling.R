## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "",
  echo = FALSE, 
  warning = FALSE, 
  message = FALSE
)

## ----setup, include=FALSE------------------------------------------------
# De esta manera separo el código de los datos y el codigo del modelo y sólo trabajo con un único archivo de tratamiento de datos.
library(surveyA3Madrid)
library(tidyverse)
data(dataSurveyA3)

## ------------------------------------------------------------------------
table(dataSurveyA3$municipio,dataSurveyA3$carpooling,useNA = c("ifany"))

## ---- include=FALSE------------------------------------------------------
dataSurveyA3_carpooling <- dataSurveyA3 %>% filter(municipio=="Arganda"&!is.na(Barrio_Destino_Name))

## ------------------------------------------------------------------------
table(dataSurveyA3_carpooling$vehiculo,dataSurveyA3_carpooling$carpooling,useNA = c("ifany"))

## ------------------------------------------------------------------------
table(dataSurveyA3_carpooling$carnet,dataSurveyA3_carpooling$carpooling,useNA = c("ifany"))

## ---- include=FALSE------------------------------------------------------
dataSurveyA3_carpooling <- dataSurveyA3_carpooling %>% filter(vehiculo!="No"& vehiculo!="Yes_Passenger")

## ---- include=FALSE------------------------------------------------------
library(sampleSelection)

